export const BASE_URL = process.env.REACT_APP_BASE_URL;
export const API_URL = process.env.REACT_APP_API_URL;
export const PRESET_KEY= process.env.REACT_APP_PRESET_KEY;
export const CLOUDINARY_URL= process.env.REACT_APP_CLOUDINARY_URL;
export const CLOUD_NAME= process.env.REACT_APP_CLOUD_NAME;
